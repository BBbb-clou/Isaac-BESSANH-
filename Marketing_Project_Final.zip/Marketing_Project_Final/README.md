# Estimation of YouTube Video Impact
Analyse Marketing de Vidéos YouTube avec LLMs et Google Video Intelligence

# 1 Description of the projet

This project proposes an automatic analysis solution for YouTube videos from a marketing perspective, in order to estimate their overall impact through a score ranging from 0 to 100.

The evaluation combines multiple sources of information:

-Technical and visual features (brightness, contrast, sharpness, dominant colors, codecs, etc.)

-Audio metrics (RMS volume, noise, frequency spectrum)

-Results from the Google Video Intelligence API (detected objects, scenes, shot transitions)

-Qualitative analysis by LLMs: Gemini, ChatGPT, Claude



# 2 Main features


YouTube download: Automatically downloads the video and its metadata from its URL via yt-dlp.

Metadata extraction: Retrieves the title, duration, number of views, likes, and comments.

Visual analysis: Calculates average brightness, contrast, sharpness, and dominant color.

Audio analysis: Measures RMS volume, noise, and frequency spectrum with librosa.

Google Video Intelligence: Detects objects, scenes, and shot transitions.

Feature fusion: Aggregates all data into a usable DataFrame for analysis.

LLM-based analysis (Gemini / ChatGPT): Generates scores and personalized marketing recommendations.
---

# 3 Installation and configuration

## 3. 1 Installation of dependencies 
To ensure the code runs properly, you need to install the required packages. Below is the basic installation code.

%pip install yt-dlp google-generativeai google-cloud-videointelligence librosa opencv-python pandas tqdm

## 3.2 Required API keys

#3. 2.1 Google Video Intelligence : 
To access the Google Video Intelligence features, you must create a service key from the Google Cloud Console. 
In your code, download the JSON file of your key and specify its path:
KEY_PATH = "/content/mon-projet-google-key.json"

#3. 2.2 Gemini (Google Generative AI) :
To access Gemini’s features, you must create and store your API key in a secret folder. The API name will be:
GOOGLE_API_KEY

# 3. 2.3 OpenAI (ChatGPT) :
To access Gemini’s features, you must create and store your API key in a secret folder. The API name will be
OPENAI_API_KEY


# 4  How to use

Step 1 : Download a YouTube video

video_urls = ["https://www.youtube.com/watch?v=dQw4w9WgXcQ"]
The script automatically downloads the video and its metadata into the /content/videos folder

Step 2 :Extract feature

video_features = analyze_visual_quality(video_path)
audio_features = analyze_audio(video_path)

Step 3 : Analyze video with Google Video Intelligence

results = analyze_video_with_key(VIDEO_PATH, key_path=KEY_PATH)
→ "Provides the number of shot changes and detected objects""

Step 4 : Merge the results into a DataFrame

df = pd.DataFrame(video_features)
display(df.head())

Step 5 : Analyze with the LLMs
🔹 Avec Gemini

response = model.generate_content(user_prompt)
display(Markdown(response.text))

🔹 Avec ChatGPT

response = client.chat.completions.create(...)
display(Markdown(output_text))

Both models assign scores by dimension (audio, visual, description, etc.) and provide marketing recommendations



##  Streamlit application

## 1 Streamlit application — Analyze Marketing Vidéo

## 1.1 This Streamlit application provides a simple and interactive interface to locally run the complete pipeline for marketing analysis of YouTube videos.
It allows you to:

-import or upload a video,

-automatically extract its technical, visual, and audio features,

-use the Google Video Intelligence and LLMs (Gemini / ChatGPT) APIs to generate a detailed marketing analysis

## 1.2 Quick start

## A. Installation of dependencies 

After installing the packages listed above, install the package required to run your Streamlit application :
pip install streamlit yt-dlp

## B. Additional information

Place the .json file of your Google Video Intelligence API key in your local folder. 
Also create a video folder to store the downloaded videos. 
Make sure you have installed the ffmpeg executable file.

## 1. 3 Launch the application.
streamlit run app.py

## 1.4 the Files

The files testepro.ipynb and app.py contain, respectively, the code to implement our product from start to finish, and the code for the Streamlit application.

