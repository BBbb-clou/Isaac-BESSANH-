# Installation de package
install.packages("tseries")
install.packages("forecast")
install.packages("urca")
install.packages("gsignal")

# Chargement des packages
library(tseries)
library(forecast)
library(urca)
library(gsignal)

# Question a) -----------------------------------------------------------

# Importation des données
X <- readRDS(file = "C:/Users/Users/Desktop/les cours/serie temp/project/data_ts.rds")
print(X) # Pour visualiser les données

# Création d'une figure avec le graphique de la série, ACF et PACF
op <- par(no.readonly = TRUE)
layout(matrix(c(1, 1, 2, 3), 2, 2, byrow = TRUE))
plot.ts(X, main = "Série temporelle X[t]", ylab = "Valeurs")
acf(X, main = "ACF de X[t]")
pacf(X, main = "PACF de X[t]")
par(op)

# Test de Dickey Fuller pour vérifier la présence d'une racine unitaire
# Test avec tendance (modèle avec constante et tendance)
adf_test_trend <- ur.df(X, type = "trend", lags = 1)
cat("Test avec tendance déterministe (type='trend'):\n")
print(summary(adf_test_trend))

# Test sans tendance (modèle avec constante uniquement)
cat("\n")
cat("Test avec constante uniquement (type='drift'):\n")
adf_test_drift <- ur.df(X, type = "drift", lags = 1)
print(summary(adf_test_drift))

# Test sans constante ni tendance
cat("\n")
cat("Test sans constante ni tendance (type='none'):\n")
adf_test_none <- ur.df(X, type = "none", lags = 1)
print(summary(adf_test_none))

# Décomposition de la série en ses composantes
X_ts <- ts(X, frequency = 4)
fit_stl <- stl(X_ts, s.window = "periodic")
plot(fit_stl)

# Extraction  des composantes
trend <- fit_stl$time.series[, "trend"]
seasonal <- fit_stl$time.series[, "seasonal"]
remainder <- fit_stl$time.series[, "remainder"]

# Détermination de  la fréquence de la série
s <- frequency(X)
cat("Fréquence de la série:", s, "\n")


# Question b) -----------------------------------------------------------

# Estimation de la tendance 
T <- length(X)
time <- 1:T
trend_model <- lm(X ~ time + I(time^2))
summary(trend_model)

# Extraction la tendance estimée
trend_estimated <- fitted(trend_model)


# Détendre la série
Y <- X - trend
plot(Y, main = "Série Y[t] sans tendance", ylab = "Résidu", xlab = "Temps")


# Vérifions si Y est stationnaire
# Test de Dickey-Fuller sur la série X
adf_result <- adf.test(Y)
print(adf_result)

# Vérifions si la saisonalité est stationaire
adf_result <- adf.test(seasonal)
print(adf_result)
# Stationnarisation 
Z_diff1 <- diff(Y, lag = 1)
Z_diff2<-diff(Z_diff1, lag = 1)
Z<-diff(Z_diff2, lag = 4)

op <- par(no.readonly = TRUE)
layout(matrix(c(1, 1, 2, 3), 2, 2, byrow = TRUE))
plot.ts(Z, main = "Série stationnarisée Z[t]", ylab = "Valeurs")
acf(Z, main = "ACF de Z[t]")
pacf(Z, main = "PACF de Z[t]")
par(op)

adf_result <- adf.test(Z)
print(adf_result)
 

# Question c) -----------------------------------------------------------

# c1) Spécification et estimation des paramètres du modèle SARIMA

library(forecast)

T <- length(X)
s <- 4  # Période de saisonnalité

# Sous-ensemble d'apprentissage : les T-s premières valeurs de la série stationnarisée
Z_train <- Z[1:(T - s)]

## Estimation du modèle 

# Estimation du modèle SARIMA avec auto.arima et bornes sur les ordres
sarima_model <- auto.arima(
  Z_train,
  max.p = 3,      # borne supérieure pour p
  max.q = 3,      # borne supérieure pour q
  max.P = 2,      # borne supérieure pour P
  max.Q = 2,      # borne supérieure pour Q
  max.d = 0,      # pas de différenciation supplémentaire (déjà stationnarisé)
  max.D = 0,      # pas de différenciation saisonnière supplémentaire
  seasonal = FALSE,
  stepwise = TRUE,   # recherche exhaustive pour plus de précision
  approximation = FALSE, # pas d'approximation
  trace = TRUE         # pour afficher le processus de sélection
)

# Afficher le résumé du modèle estimé
summary(sarima_model)





# Question d) -----------------------------------------------------------


#Définissons T et s
# Question d

s <-4  # Période de saisonnalité

# Sous-ensemble d'apprentissage : les T-s premières valeurs de la série stationnarisée
Y_train <- Y[1:(T - s)]

# Ajuster un modèle ARIMA automatiquement sur la série d'entraînement
model <- auto.arima(Y_train)

# Prévision s-steps ahead
forecast_result <- forecast(model, h = s, level = 95)

# Extraire les vraies valeurs (validation)
y_validation <- Y[(T - s + 1):T]

# Tracer la prévision
plot(forecast_result, main = "Prévision à s étapes avec intervalle de confiance à 95%", xlab = "Temps", ylab = "y[t]")
lines((T - s + 1):T, y_validation, col = "red", lwd = 2, type = "b", pch = 16)
legend("topleft", legend = c("Prévision", "Intervalle 95%", "Observations réelles"),
       col = c("blue", "gray", "red"), lty = c(1, NA, 1), pch = c(NA, NA, 16), lwd = c(2, NA, 2), bty = "n")

# Calcul de l'erreur quadratique moyenne (RMSE)
rmse <- sqrt(mean((y_validation - forecast_result)^2))
cat("Erreur quadratique moyenne (RMSE) :", rmse, "\n")

# MAE (erreur absolue moyenne)
mae <- mean(abs(y_validation - forecast_result))
cat("Erreur absolue moyenne (MAE) :", mae, "\n")


# Question e) -----------------------------------------------------------

time <- 1:length(X)
trend_model <- lm(X ~ time + I(time^2)) # estimation du modèle de la tendance

# Estiamtion de la tendance 
trend_estimated <- predict(trend_model, newdata = data.frame(time = time))

# Estiamtion de la tendance au temps T+1 

trend_Tplus1 <- predict(trend_model, newdata = data.frame(time = T+1))

# Estimation de la saisonnalité
seasonal_pattern <- tapply(X - trend_estimated, rep(1:4, length.out=length(X)), mean)

# Prévision saisonnalité à T+1
seasonal_Tplus1 <- seasonal_pattern[(T+1) %% 4]
if (seasonal_Tplus1 == 0) seasonal_Tplus1 <- 4


# Prévision sur Z  avec ARIMA(2,0,2)

forecast_Z <- forecast(sarima_model, n.ahead = 1)

## Prédiction ponctuelle
pred_Z <- forecast_Z$mean[1]

## Standard error

upper_95 <- forecast_Z$upper[1, 2]
se_Z <- (upper_95 - pred_Z) /1.96

# Prévision  X[T+1]

pred_X <- pred_Z + trend_Tplus1 + seasonal_Tplus1

## Intervalle de confiance
lower_X <- pred_X - 1.96 * se_Z
upper_X <- pred_X + 1.96 * se_Z

cat("Prévision X[T+1] :", pred_X, "\n")
cat("Intervalle de confiance à 95% : [", lower_X, ",", upper_X, "]\n")


