
##Traitement des bases brutes
#chargement des packages

library(tidyverse)
library(dplyr)
library(plm)
library(fixest)
library(readr)
library(readxl)
library(gridExtra)
library(texreg)
library(tidyr)


## Traitement des bases importation et exportation des produits 
data <- read_excel("C:/Users/Users/Desktop/base pro emp/importation plastique.xls.xlsx")

# Transformation des données
data_long <- data %>%
  pivot_longer(
    cols = -Pays,
    names_to = "Annee",
    values_to = "Valeur"
  )%>%
  rename(Importation=Valeur)
 
data_long$Produit<-'Plastic'

data1 <- read_excel("C:/Users/Users/Desktop/base pro emp/export plastic.xlsx")
# Transformation des données
data_long1 <- data1 %>%
  pivot_longer(
    cols = -Pays,
    names_to = "Annee",
    values_to = "Valeur"
  )%>%
  rename(Exportation=Valeur)

data_long1$Produit<-'Plastic'



data2 <- read_excel("C:/Users/Users/Desktop/base pro emp/importation fer, acier.xls.xlsx")
# Transformation des données
data_long2 <- data2 %>%
  pivot_longer(
    cols = -Pays,
    names_to = "Annee",
    values_to = "Valeur"
  )%>%
  rename(Importation=Valeur)

data_long2$Produit<-'Fer,acier'



data3 <- read_excel("C:/Users/Users/Desktop/base pro emp/exportations fer, acier.xls.xlsx")
# Transformation des données
data_long3 <- data3 %>%
  pivot_longer(
    cols = -Pays,
    names_to = "Annee",
    values_to = "Valeur"
  )%>%
  rename(Exportation=Valeur)

data_long3$Produit<-'Fer,acier'



data4 <- read_excel("C:/Users/Users/Desktop/base pro emp/importation bois, charbon de bois.xls.xlsx")
# Transformation des données
data_long4 <- data4 %>%
  pivot_longer(
    cols = -Pays,
    names_to = "Annee",
    values_to = "Valeur"
  )%>%
  rename(Importation=Valeur)

data_long4$Produit<-'Bois, charbon de bois'



data5 <- read_excel("C:/Users/Users/Desktop/base pro emp/exportation bois,charbon.xls.xlsx")
# Transformation des données
data_long5 <- data5 %>%
  pivot_longer(
    cols = -Pays,
    names_to = "Annee",
    values_to = "Valeur"
  )%>%
  rename(Exportation=Valeur)

data_long5$Produit<-'Bois, charbon de bois'

## Fusion des bases de données

df_import<-rbind(data_long, data_long2, data_long4)
df_export<-rbind(data_long1, data_long3,data_long5)

merged_data <- merge(df_import, df_export, by = c("Pays", "Annee", "Produit"))
dataf<-merged_data


# Affichage des premières lignes de la base de données mise à jour
head(dataf)

## Statistique desdcriptive de la base de données.
str(dataf)

df_wide <- dataf %>%
  pivot_wider(names_from = Produit, values_from = c(Importation, Exportation), names_glue = "{.value}_{Produit}")

# Affichage du nouveau dataframe
print(df_wide)

#### Traitement de la base de nos variables de contrôles

Base <- read_delim("C:/Users/Users/Desktop/Classeur1.csv", 
                        delim = ";", escape_double = FALSE, na = "0", 
                        trim_ws = TRUE)


# 1. Pivotter les colonnes d'années en lignes
data_long <- Base%>%
  pivot_longer(cols = 3:ncol(Base), names_to = "Annee", values_to = "Valeur")

# 2. Pivotter les "Series Name" en colonnes
data_wide <- data_long %>%
  pivot_wider(names_from = "Series", values_from = "Valeur")

# 3. Réorganiser les colonnes
data_resultat <- data_wide %>%
  select(Pays, Annee, everything())

# Afficher le résultat
print(data_resultat)


# Vérifier la structure des données après conversion
str(data_resultat)


dataf1 <- dataf %>% filter(!Pays %in% c("Serbie et Monténégro", "Malte"))

dataf2 <- dataf1 %>% filter(Annee != 2024)

## Fusion  de la base de données des imporations et exportations des produits et celle de nos variables de control


df_wide <- dataf2 %>%
  pivot_wider(names_from = Produit, values_from = c(Importation, Exportation), names_glue = "{.value}_{Produit}")


Data_final <- merge(df_wide, data_resultat, by = c("Pays", "Annee"))

##création de la variable Taxe
# Créer une variable Taxe initialisée à 0
Data_final$Taxe <- 0


# Mise à jour de la colonne carbontax_it
for (i in 1:nrow(Data_final)) {
  pays <- Data_final$Pays[i]
  annee <- Data_final$Annee[i]
  
  if ((pays == "France") ||
      (pays == "Irlande") ||
      (pays == "Royaume-Uni") ||
      (pays == "Suède") ||
      (pays == "Slovénie") ||
      (pays == "Allemagne") ||
      (pays == "Finlande") ||
      (pays == "Danemark")) {
    Data_final$Taxe[i] <- 1
  }
}


## Creation de la variable Post
Data_final$Post<-0

# Mise à jour de la colonne carbontax_it
for (i in 1:nrow(Data_final)) {
  pays <- Data_final$Pays[i]
  annee <- Data_final$Annee[i]
  
  if ((pays == "France" && annee>=2014) ||
      (pays == "Irlande" && annee>=2010) ||
      (pays == "Royaume-Uni" && annee>=2005) ||
      (pays == "Suède" && annee>=2005) ||
      (pays == "Slovénie" && annee>=2015) ||
      (pays == "Allemagne" && annee >=2021) ||
      (pays == "Finlande" && annee >= 2005) ||
      (pays == "Danemark" && annee >=2005)) {
    Data_final$Post[i] <- 1
  }
}

# Création de la variable D1 (crise de 2008)
Data_final$D1 <- ifelse(Data_final$Annee == 2008, 1, 0)

# Création de la variable D2 (crise du COVID-19 en 2019)
Data_final$D2 <- ifelse(Data_final$Annee == 2019, 1, 0)

View(Data_final)


## Nombres de valeurs manquantes
# Calcul du nombre de valeurs manquantes pour chaque colonne à partir de la troisième colonne
nombre_manquants <- sapply(Data_final[, 3:ncol(Data_final)], function(x) sum(is.na(x)))

# Afficher les résultats
print(nombre_manquants)

## Imputation des valeurs amnquantes par la médiane.

# Imputer les valeurs manquantes par la médiane pour chaque colonne à partir de la troisième colonne
for (i in 3:ncol(Data_final)) {
  Data_final[is.na(Data_final[, i]), i] <- median(Data_final[, i], na.rm = TRUE)
}

# Vérifier si toutes les valeurs manquantes ont été imputées
print(sapply(Data_final[, 3:ncol(Data_final)], function(x) sum(is.na(x))))

## Traitement des données de deux autres produits dont la prodution necessite moins de CO2

df1 <- read_excel("C:/Users/Users/Desktop/base pro emp/exportation cereals.xlsx")
# Transformation des données

df_long1 <- df1 %>%
  pivot_longer(
    cols = -Pays,
    names_to = "Annee",
    values_to = "Valeur"
  )

df_long1$Produit <- 'Cereals'
df_long1 <- df_long1 %>%
  rename(Exportation = Valeur)


df2 <- read_excel("C:/Users/Users/Desktop/base pro emp/importation cereals.xlsx")
# Transformation des données
df_long2 <- df2 %>%
  pivot_longer(
    cols = -Pays,
    names_to = "Annee",
    values_to = "Valeur"
  )

df_long2$Produit <- 'Cereals'
df_long2 <- df_long2 %>%
  rename(Importation = Valeur)



df3 <- read_excel("C:/Users/Users/Desktop/base pro emp/importation vegetal products.xlsx")
# Transformation des données
df_long3 <- df3 %>%
  pivot_longer(
    cols = -Pays,
    names_to = "Annee",
    values_to = "Valeur"
  )

df_long3$Produit <- 'vegetal products'
df_long3 <- df_long3 %>%
  rename(Importation = Valeur)



df4 <- read_excel("C:/Users/Users/Desktop/base pro emp/exportation vegetal products.xlsx")
# Transformation des données
df_long4 <- df4 %>%
  pivot_longer(
    cols = -Pays,
    names_to = "Annee",
    values_to = "Valeur"
  )

df_long4$Produit <- 'vegetal products'
df_long4 <- df_long4 %>%
  rename(Exportation = Valeur)



## Fusion des bases de données

data_import<-rbind(df_long2,df_long3)
data_export<-rbind(df_long1,df_long4)

merged_data <- merge(data_import, data_export, by = c("Pays", "Annee", "Produit"))
data_final<-merged_data



## Nombres de valeurs manquantes


# Calculer le nombre de valeurs manquantes pour chaque colonne à partir de la troisième colonne
nombre_manquants <- sapply(Base_Final[, 3:ncol(Base_Final)], function(x) sum(is.na(x)))

# Afficher les résultats
print(nombre_manquants)

## Imputation des valeurs amnquantes par la médiane.

# Imputer les valeurs manquantes par la médiane pour chaque colonne à partir de la troisième colonne
for (i in 3:ncol(Base_Final)) {
  Base_Final[is.na(Base_Final[, i]), i] <- median(Base_Final[, i], na.rm = TRUE)
}

# Vérifier si toutes les valeurs manquantes ont été imputées
print(sapply(Base_Final[, 3:ncol(Base_Final)], function(x) sum(is.na(x))))
      

data_wide2 <- data_final %>%
pivot_wider(names_from = Produit, values_from = c(Importation, Exportation), names_glue = "{.value}_{Produit}")
      

data_wide2 <- data_wide2 %>%
rename(`Importationvegetal` = `Importation_vegetal products`)
      
data_wide2 <- data_wide2 %>%
rename(`Emportationvegetal` = `Exportation_vegetal products`)
      
      
data_wide2 <- data_wide2 %>%
rename(`Importationcereals` = `Importation_Cereals`)
      
data_wide2 <- data_wide2 %>%
rename(`Exportationcereals` = `Exportation_Cereals`)
      
Base_Final <- merge(data_wide2, Data_final, by = c("Pays", "Annee"))
      
## Conversion de quelque variable
Base_Final <- Base_Final %>%
  rename(`Exportation` = `Exportation(%PIB)`)

Base_Final <- Base_Final %>%
  rename(`Importation` = `Importation(%PIB)`)

## Creation de la variable d'interaction

Base_Final$Post_taxe=Base_Final$Post*Base_Final$Taxe

# Enregistrement des  bases 
#Les Bases  intermediares des produits: cereals , vegetal
chemin <- "C:/Users/Users/Desktop/les cours/conducting project/Empirical_Project_BESSANH_Isaac_YAYRA_Cybelle_GBODOGBE_Zinsou_René/Data/Temp/data_wide2.csv"
write.csv(as.data.frame(data_wide2), file = chemin, row.names = FALSE)


# les bases des importations, les exportations , CO2, Taxe, consommation finale, Inflation, PIB par tête, Post*taxe, charbon de bois, fer et acier, plastiques

chemin <- "C:/Users/Users/Desktop/les cours/conducting project/Empirical_Project_BESSANH_Isaac_YAYRA_Cybelle_GBODOGBE_Zinsou_René/Data/Temp/Data_Final.csv"
write.csv(as.data.frame(Data_final), file = chemin, row.names = FALSE)


#Base_final 

# chemin 
chemin <- "C:/Users/Users/Desktop/les cours/conducting project/Empirical_Project_BESSANH_Isaac_YAYRA_Cybelle_GBODOGBE_Zinsou_René/Data/Final/Base_Final.csv"
write.csv(as.data.frame(Base_Final), file = chemin, row.names = FALSE)


