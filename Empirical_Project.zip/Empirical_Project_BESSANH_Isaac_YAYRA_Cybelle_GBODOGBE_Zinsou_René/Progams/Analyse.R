# Analyse des de la base de données

## Les bibliothèques nécessaires

library(tidyverse)
library(dplyr)
library(plm)
library(fixest)
library(readr)
library(readxl)
library(gridExtra)
library(texreg)



# Importation de la base de données
Base_Final <- read_csv("C:/Users/Users/Desktop/les cours/conducting project/Empirical_Project_BESSANH_Isaac_YAYRA_Cybelle_GBODOGBE_Zinsou_René/Data/Final/Base_Final.csv")# Statistiques Descriptives 


## Statistiques descriptive
# Réalisation des  Graphiques pour la statistique descriptive 

# Liste des pays à inclure
pays_selectionnes <- c("France", "Suède", "Danemark","Irlande","Royaume-Uni","Slovénie","Allemagne","Finlande")

# Filtrage des données pour les pays sélectionnés
data_filtrees <- Base_Final[Base_Final$Pays %in% pays_selectionnes, ]

# Vérifions que  les données sont numériques
data_filtrees$Annee <- as.numeric(data_filtrees$Annee)
data_filtrees$CO2 <- as.numeric(data_filtrees$CO2)

# Création des graphiques
p0<-ggplot(data_filtrees, aes(x = Annee, y = CO2, color = Pays)) +
  geom_line() +
  geom_point() +  # Ajouter des points pour une meilleure visualisation
  labs(title = "Évolution du CO2 ",
       x = "Année",
       y = "CO2") +
  theme_minimal() +
  scale_color_brewer(palette = "Set1") # Utiliser une palette de couleurs distinctes


## Evolution des exportations et des importations des pays ayant appliqués la taxe 

# Liste des pays à inclure
pays_selectionnes <- c("France", "Suède", "Danemark", "Irlande", "Royaume-Uni", "Slovénie", "Allemagne", "Finlande")

# Filtrage des données pour les pays sélectionnés
data_filtrees <- Base_Final[Base_Final$Pays %in% pays_selectionnes, ]

# vérifions que les données sont numériques
data_filtrees$Annee <- as.numeric(data_filtrees$Annee)
data_filtrees$Exportation <- as.numeric(data_filtrees$Exportation)
# Création du   graphique
p1<-ggplot(data_filtrees, aes(x = Annee, color = Pays)) +
  geom_line(aes(y = Exportation, linetype = "Exportations")) +
  labs(title = "Évolution des Exportations (%PIB)",
       x = "Année",
       y = "% du PIB") +
  theme_minimal() +
  scale_color_brewer(palette = "Set1") + # Utiliser une palette de couleurs distinctes
  scale_linetype_manual(values = c("solid", "dashed")) 

## Evolution des importations

# vérifions  que les données sont numériques
data_filtrees$Annee <- as.numeric(data_filtrees$Annee)
data_filtrees$Importation <- as.numeric(data_filtrees$Importation)
# Création de graphique
p2<-ggplot(data_filtrees, aes(x = Annee, color = Pays)) +
  geom_line(aes(y = Importation, linetype = "Importation")) +
  labs(title = "Évolution des Importations(%PIB)",
       x = "Année",
       y = "% du PIB") +
  theme_minimal() +
  scale_color_brewer(palette = "Set1") + # Utiliser une palette de couleurs distinctes
  scale_linetype_manual(values = c("solid", "dashed")) # Lignes pleines et tiretées



## Evolution du PIB

# vérifions que les données sont numériques
data_filtrees$Annee <- as.numeric(data_filtrees$Annee)
data_filtrees$`PIB` <- as.numeric(data_filtrees$`PIB`)
# Création du graphique
p3<-ggplot(data_filtrees, aes(x = Annee, color = Pays)) +
  geom_line(aes(y = `PIB`, linetype = "PIB")) +
  labs(title = "Évolution du PIB",
       x = "Année",
       y = "PIB") +
  theme_minimal() +
  scale_color_brewer(palette = "Set1") + # Utiliser une palette de couleurs distinctes
  scale_linetype_manual(values = c("solid", "dashed")) # Lignes pleines et tiretées

## Combinaison des graphiques
grid.arrange(p1, p2,p3, p0,ncol = 2) # Pour une disposition en ligne

## Barplot des produits pour les importaions et les exportations
# Assurons-nous que les colonnes sont numériques
dataf2$Importation <- as.numeric(dataf2$Importation)
dataf2$Exportation <- as.numeric(dataf2$Exportation)

# Graphique pour les importations
p5 <- ggplot(dataf2, aes(y = Produit, x = Importation)) +
  geom_bar(stat = "identity", fill = "skyblue") +
  labs(title = "Importations par Produit",
       x = "Importations",
       y = "Produit") +
  theme_minimal()

# Graphique pour les exportations
p6 <- ggplot(dataf2, aes(y = Produit, x = Exportation)) +
  geom_bar(stat = "identity", fill = "lightgreen") +
  labs(title = "Exportations par Produit",
       x = "Exportations",
       y = "Produit") +
  theme_minimal()

# Afficher les graphiques
grid.arrange(p5, p6,ncol = 1) # Pour une disposition en ligne

# Statistiques descriptives pour les colonnes numériques
summary( Base_Final)


##Exportation

## Verification de l'hypothèse de la tendance commune

p11 <- ggplot(Base_Final, aes(x=Annee, y=Exportation, color=as.factor(Post)))+geom_line()+
  labs(title = "Common trend for exportation", y='Exportation',x="Annee")


# importation

p12 <-ggplot(Base_Final, aes(x=Annee, y=Importation, color=as.factor(Post)))+geom_line()+
  labs(title = "Common trend for importation", y='Importation',x="Annee")

# C02

p13 <-ggplot(Base_Final, aes(x=Annee, y=CO2, color=as.factor(Post)))+geom_line()+
  labs(title = "Common Trend for C02 emission", y='Exportation',x="Annee")

# Concatenation des graphes.

grid.arrange(p11, p12,p13,ncol = 2)


##############################################################################################

## Estimation des Models
# Conversion des colonnes nécessaires en facteurs et numériques
Base_Final$Pays <- as.factor(Base_Final$Pays)
Base_Final$Annee <- as.factor(Base_Final$Annee)
Base_Final$Post <- as.numeric(Base_Final$Post)
Base_Final$Taxe <- as.numeric(Base_Final$Taxe)
Base_Final$PIB <- as.numeric(Base_Final$PIB)
Base_Final$Consumption <- as.numeric(Base_Final$Final_consumption)
Base_Final$Inflation <- as.numeric(Base_Final$Inflation)
Base_Final$Export <- as.numeric(Base_Final$Exportation)
Base_Final$CO2<- as.numeric(Base_Final$CO2)

# Rename the variables names

## Importation

Base_Final<-Base_Final%>%
  rename(Importation_Bois_charbon_de_bois=`Importation_Bois, charbon de bois`)

Base_Final<-Base_Final%>%
  rename(Importaion_Fer_Acier=`Importation_Fer,acier`)

## Exportation

Base_Final<-Base_Final%>%
  rename(Export_Bois_charbon_de_bois=`Exportation_Bois, charbon de bois`)


Base_Final<-Base_Final%>%
  rename(Export_Fer_Acier=`Exportation_Fer,acier`)

library(plm)

# Création de  la variable d'interaction Post*Taxe
Base_Final$Post_Taxe <- Data_final$Post * Data_final$Taxe

## Model pour exportation aggregée

# Charger le package
library(fixest)

## Create the interaction variable
Base_Final$Post_Taxe<- Base_Final$Post*Base_Final$Taxe

## Estimation

model1 <- feols(Exportation ~ Post_Taxe + PIB + Inflation + Consumption| Pays + Annee, data = Base_Final)

summary(model1)


## Model pour importation aggregée

model2<- feols(Importation~ Post_Taxe + PIB + Inflation + Consumption| Pays + Annee, data = Base_Final)

summary(model2)

## C02

model3<- feols(CO2~ Post_Taxe + PIB + Inflation + Consumption | Pays + Annee, data = Base_Final)

summary(model3)

## Results together

library(texreg)

screenreg(list(model1, model2, model3), 
          custom.model.names = c("Exportation", "Importation", " CO2 emission"),
          custom.coef.names = c("Post Taxe", "PIB", "Inflation", "Consommation"))



## Model d'importation des produits dont la production necessite plus d'émission de C02

# Rename the variables names

## Importation

Base_Final<-Base_Final%>%
  rename(Importation_Bois_charbon_de_bois=`Importation_Bois, charbon de bois`)

Base_Final<-Base_Final%>%
  rename(Importaion_Fer_Acier=`Importation_Fer,acier`)

## Exportation

Base_Final<-Base_Final%>%
  rename(Export_Bois_charbon_de_bois=`Exportation_Bois, charbon de bois`)


Base_Final<-Base_Final%>%
  rename(Export_Fer_Acier=`Exportation_Fer,acier`)

###############################################################################

## Estimation de l'effet de carbon taxe sur les importations de charbon de bois, fer et acier, plastic

model4<- feols(log(Importation_Bois_charbon_de_bois)~ Post_Taxe + PIB + Inflation + Consumption | Pays + Annee, data = Base_Final)

summary(model4)

model5<- feols(log(Importaion_Fer_Acier)~ Post_Taxe + PIB + Inflation + Consumption | Pays + Annee, data = Base_Final)

summary(model5)


model6<- feols(log(Importation_Plastic)~ Post_Taxe + PIB + Inflation + Consumption | Pays + Annee, data = Base_Final)

summary(model6)

## Results together

screenreg(list(model4, model5, model6), 
          custom.model.names = c("Bois et charchon de bois", "Fer et acier", " Plastiques"),
          custom.coef.names = c("Post_Taxe", "PIB", "Inflation", "Consumption"))



## Estimation de l'effet de carbon taxe sur les exportations de charbon de bois, fer et acier, plastic



model7<- feols(log(Export_Bois_charbon_de_bois)~ Post_Taxe + PIB + Inflation + Consumption | Pays + Annee, data = Base_Final)

summary(model7)

model8<- feols(log(Export_Fer_Acier)~ Post_Taxe + PIB + Inflation + Consumption | Pays + Annee, data = Base_Final)

summary(model8)


model9<- feols(log(Exportation_Plastic)~ Post_Taxe + PIB + Inflation + Consumption | Pays + Annee, data = Base_Final)

summary(model9)

## Results together

screenreg(list(model7, model8, model9), 
          custom.model.names = c("Bois et charchon de bois", "Fer et acier", " Plastiques"),
          custom.coef.names = c("Post_Taxe", "PIB", "Inflation", "Consumption"))



#Estimation de l'effet de carbone taxe sur les produits dont la production  nécessite moins de CO2

## Importation des produits ( ceréales, les produits végetaux)

model10<- feols(log(Importationcereals)~ Post_Taxe + PIB + Inflation + Consumption | Pays + Annee, data = Base_Final)

summary(model10)

model11<- feols(log(Importationvegetal)~ Post_Taxe + PIB + Inflation + Consumption | Pays + Annee, data = Base_Final)

summary(model11)

## Results together

screenreg(list(model10, model11), 
          custom.model.names = c("Cereals", "Vegetables"),
          custom.coef.names = c("Post_Taxe", "PIB", "Inflation", "Consumption"))


## Exportation des produits ( ceréales, les produits végetaux)

model12<- feols(log(Exportationcereals)~ Post_Taxe + PIB + Inflation + Consumption | Pays + Annee, data = Base_Final)

summary(model12)

model13<- feols(log(Emportationvegetal
)~ Post_Taxe + PIB + Inflation + Consumption | Pays + Annee, data = Base_Final)

summary(model13)

## Results together

screenreg(list(model2, model13), 
          custom.model.names = c("Cereals", "Vegetables"),
          custom.coef.names = c("Post_Taxe", "PIB", "Inflation", "Consumption"))





